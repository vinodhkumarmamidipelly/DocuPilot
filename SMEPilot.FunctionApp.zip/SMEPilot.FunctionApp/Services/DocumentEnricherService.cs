using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;
using Newtonsoft.Json;
using Microsoft.Extensions.Logging;
using Drawing = DocumentFormat.OpenXml.Drawing;
using DrawingWordprocessing = DocumentFormat.OpenXml.Drawing.Wordprocessing;

namespace SMEPilot.FunctionApp.Services
{
    /// <summary>
    /// Rule-based document enrichment service
    /// Reformats documents using organizational template and keyword-based section mapping
    /// NO AI dependencies - all logic is deterministic
    /// </summary>
    public class DocumentEnricherService
    {
        private readonly string _templatePath;
        private readonly MappingConfig _config;
        private readonly ILogger<DocumentEnricherService>? _logger;

        public DocumentEnricherService(string templatePath, string mappingJsonPath, ILogger<DocumentEnricherService>? logger = null)
        {
            _templatePath = templatePath ?? throw new ArgumentNullException(nameof(templatePath));
            _logger = logger;

            if (!File.Exists(templatePath))
            {
                throw new FileNotFoundException($"Template file not found: {templatePath}");
            }

            if (!File.Exists(mappingJsonPath))
            {
                throw new FileNotFoundException($"Mapping configuration not found: {mappingJsonPath}");
            }

            try
            {
                var json = File.ReadAllText(mappingJsonPath);
                _config = JsonConvert.DeserializeObject<MappingConfig>(json) 
                    ?? throw new InvalidOperationException("Failed to deserialize mapping configuration");
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Failed to load mapping configuration from {Path}", mappingJsonPath);
                throw;
            }
        }

        /// <summary>
        /// Enriches a document by applying template, section mapping, and classification
        /// </summary>
        /// <param name="inputPath">Path to raw .docx file downloaded from SharePoint</param>
        /// <param name="outputPath">Path where enriched .docx will be saved</param>
        /// <param name="author">Author name for revision history</param>
        /// <param name="images">Optional list of image byte arrays to embed</param>
        /// <returns>Enrichment result with status and metadata</returns>
        public EnrichmentResult Enrich(string inputPath, string outputPath, string author, List<byte[]>? images = null)
        {
            try
            {
                _logger?.LogInformation("Starting document enrichment: {InputPath} -> {OutputPath}", inputPath, outputPath);

                if (!File.Exists(inputPath))
                {
                    throw new FileNotFoundException($"Input file not found: {inputPath}");
                }

                // Extract text blocks and images from input document
                var (textBlocks, extractedImages) = ExtractContent(inputPath);
                
                // Use provided images or extracted images
                var imagesToEmbed = images ?? extractedImages;

                // Detect document type by keyword scoring
                var docType = DetectDocType(textBlocks);

                _logger?.LogInformation("Document classified as: {DocType}", docType);

                // Copy template to output location
                var outputDir = Path.GetDirectoryName(outputPath);
                if (!string.IsNullOrEmpty(outputDir) && !Directory.Exists(outputDir))
                {
                    Directory.CreateDirectory(outputDir);
                }
                File.Copy(_templatePath, outputPath, true);

                // Open template and populate sections
                using (var doc = WordprocessingDocument.Open(outputPath, true))
                {
                    var mainPart = doc.MainDocumentPart ?? throw new InvalidOperationException("Main document part not found");
                    var body = mainPart.Document?.Body ?? throw new InvalidOperationException("Document body not found");

                    // Clear existing content (keep styles)
                    body.RemoveAllChildren<Paragraph>();
                    body.RemoveAllChildren<Table>();
                    body.RemoveAllChildren<SectionProperties>();

                    // Add cover page
                    AddCoverPage(body, inputPath, author, docType);

                    // Add TOC
                    AddTableOfContents(body);

                    // Process each section from mapping config
                    foreach (var sectionRule in _config.Sections)
                    {
                        // Skip revision history - we'll add it at the end
                        if (sectionRule.Name.Contains("Revision History", StringComparison.OrdinalIgnoreCase))
                            continue;

                        // Find matching content for this section
                        var matchingText = FindMatchingContent(textBlocks, sectionRule.Keywords);

                        // Add section with content
                        AppendSection(body, sectionRule.Name, matchingText, sectionRule.Mandatory);

                        // If this is Screenshots section, add images
                        if (sectionRule.Name.Contains("Screenshot", StringComparison.OrdinalIgnoreCase) && 
                            imagesToEmbed != null && imagesToEmbed.Count > 0)
                        {
                            AddImagesToSection(body, mainPart, imagesToEmbed);
                        }
                    }

                    // Add revision history table at the end
                    AddRevisionHistory(body, author, "Rule-based enrichment applied");

                    // Save document
                    mainPart.Document?.Save();
                }

                _logger?.LogInformation("Document enrichment completed successfully: {OutputPath}", outputPath);

                return new EnrichmentResult
                {
                    Success = true,
                    DocumentType = docType,
                    EnrichedPath = outputPath,
                    Status = "Formatted"
                };
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Document enrichment failed: {ErrorMessage}", ex.Message);
                return new EnrichmentResult
                {
                    Success = false,
                    ErrorMessage = ex.Message,
                    Status = "Failed"
                };
            }
        }

        /// <summary>
        /// Extracts text blocks and images from input document
        /// </summary>
        private (List<string> textBlocks, List<byte[]> images) ExtractContent(string inputPath)
        {
            var textBlocks = new List<string>();
            var images = new List<byte[]>();

            try
            {
                using (var doc = WordprocessingDocument.Open(inputPath, false))
                {
                    var mainPart = doc.MainDocumentPart;
                    if (mainPart?.Document?.Body != null)
                    {
                        // Extract paragraphs as text blocks
                        textBlocks = mainPart.Document.Body
                            .Descendants<Paragraph>()
                            .Select(p => p.InnerText.Trim())
                            .Where(t => !string.IsNullOrWhiteSpace(t) && t.Length > 10) // Filter very short lines
                            .ToList();

                        // Extract images
                        var imageParts = mainPart.ImageParts;
                        if (imageParts != null)
                        {
                            foreach (var imgPart in imageParts)
                            {
                                using var imgStream = imgPart.GetStream();
                                using var ms = new MemoryStream();
                                imgStream.CopyTo(ms);
                                images.Add(ms.ToArray());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger?.LogWarning(ex, "Error extracting content from {Path}, continuing with empty content", inputPath);
            }

            return (textBlocks, images);
        }

        /// <summary>
        /// Detects document type by keyword scoring
        /// </summary>
        private string DetectDocType(IEnumerable<string> textBlocks)
        {
            var fullText = string.Join(" ", textBlocks).ToLower();

            var functionalScore = _config.FunctionalKeywords.Count(kw => fullText.Contains(kw.ToLower()));
            var technicalScore = _config.TechnicalKeywords.Count(kw => fullText.Contains(kw.ToLower()));
            var supportScore = _config.SupportKeywords.Count(kw => fullText.Contains(kw.ToLower()));

            // Return classification with highest score
            if (technicalScore >= supportScore && technicalScore >= functionalScore && technicalScore > 0)
                return "Technical";
            else if (supportScore >= functionalScore && supportScore > 0)
                return "Support";
            else if (functionalScore > 0)
                return "Functional";
            else
                return "Generic";
        }

        /// <summary>
        /// Finds content blocks that match section keywords
        /// </summary>
        private List<string> FindMatchingContent(List<string> textBlocks, List<string> keywords)
        {
            if (keywords == null || keywords.Count == 0)
                return new List<string>();

            var matching = new List<string>();
            var lowerKeywords = keywords.Select(k => k.ToLower()).ToList();

            foreach (var block in textBlocks)
            {
                var lowerBlock = block.ToLower();
                if (lowerKeywords.Any(kw => lowerBlock.Contains(kw)))
                {
                    matching.Add(block);
                }
            }

            return matching;
        }

        /// <summary>
        /// Adds a section to the document body
        /// </summary>
        private void AppendSection(Body body, string heading, List<string> content, bool mandatory)
        {
            // Add section heading
            var headingPara = new Paragraph(new Run(new Text(heading)))
            {
                ParagraphProperties = new ParagraphProperties(
                    new ParagraphStyleId() { Val = "Heading1" },
                    new SpacingBetweenLines() { After = "240" })
            };
            body.AppendChild(headingPara);

            // Add page break before section (except first)
            if (body.ChildElements.Count > 1)
            {
                body.AppendChild(new Paragraph(new Run(new Break() { Type = BreakValues.Page })));
            }

            // Add content paragraphs
            if (content != null && content.Any())
            {
                foreach (var text in content)
                {
                    var para = new Paragraph(new Run(new Text(text)))
                    {
                        ParagraphProperties = new ParagraphProperties(
                            new ParagraphStyleId() { Val = "Normal" },
                            new SpacingBetweenLines() { After = "120" })
                    };
                    body.AppendChild(para);
                }
            }
            else if (mandatory)
            {
                // Add placeholder for mandatory sections with no content
                var placeholderPara = new Paragraph(
                    new Run(new Text("This section is not applicable for this document."))
                    {
                        RunProperties = new RunProperties(new Italic())
                    })
                {
                    ParagraphProperties = new ParagraphProperties(
                        new ParagraphStyleId() { Val = "Normal" },
                        new SpacingBetweenLines() { After = "120" })
                };
                body.AppendChild(placeholderPara);
            }
        }

        /// <summary>
        /// Adds images to the Screenshots section
        /// </summary>
        private void AddImagesToSection(Body body, MainDocumentPart mainPart, List<byte[]> images)
        {
            int idx = 0;
            foreach (var imgBytes in images)
            {
                idx++;
                try
                {
                    // Use TemplateBuilder's image embedding logic
                    var imagePartType = DetectImageFormat(imgBytes);
                    var imagePart = mainPart.AddImagePart(imagePartType);
                    
                    using var imgStream = new MemoryStream(imgBytes);
                    imagePart.FeedData(imgStream);
                    var imageRelId = mainPart.GetIdOfPart(imagePart);

                    // Calculate dimensions
                    var (widthEmu, heightEmu) = CalculateImageDimensions(imgBytes);
                    var altText = $"Figure {idx}: Screenshot from document";

                    // Create inline drawing
                    var inline = CreateImageInline(imageRelId, widthEmu, heightEmu, idx, altText);
                    var drawing = CreateDrawingWrapper(inline);

                    // Add image paragraph
                    var imagePara = new Paragraph();
                    var run = new Run();
                    run.AppendChild(drawing);
                    imagePara.Append(run);
                    imagePara.ParagraphProperties = new ParagraphProperties(
                        new Justification() { Val = JustificationValues.Center },
                        new SpacingBetweenLines() { After = "120" });
                    
                    body.AppendChild(imagePara);

                    // Add caption
                    var captionPara = new Paragraph(new Run(new Text($"Figure {idx}: Screenshot from original document")))
                    {
                        ParagraphProperties = new ParagraphProperties(
                            new Justification() { Val = JustificationValues.Center },
                            new ParagraphStyleId() { Val = "Caption" },
                            new SpacingBetweenLines() { After = "240" })
                    };
                    body.AppendChild(captionPara);
                }
                catch (Exception ex)
                {
                    _logger?.LogWarning(ex, "Failed to embed image {Index}", idx);
                    // Add error note
                    var errorPara = new Paragraph(new Run(new Text($"Figure {idx}: Image could not be embedded")))
                    {
                        ParagraphProperties = new ParagraphProperties(
                            new Justification() { Val = JustificationValues.Center },
                            new SpacingBetweenLines() { After = "240" })
                    };
                    body.AppendChild(errorPara);
                }
            }
        }

        /// <summary>
        /// Adds cover page with document metadata
        /// </summary>
        private void AddCoverPage(Body body, string inputPath, string author, string docType)
        {
            var fileName = Path.GetFileNameWithoutExtension(inputPath);

            // Title
            body.AppendChild(new Paragraph(new Run(new Text(fileName)))
            {
                ParagraphProperties = new ParagraphProperties(
                    new ParagraphStyleId() { Val = "Title" },
                    new SpacingBetweenLines() { After = "240" })
            });

            // Metadata
            body.AppendChild(new Paragraph(new Run(new Text($"Document Type: {docType}")))
            {
                ParagraphProperties = new ParagraphProperties(
                    new ParagraphStyleId() { Val = "Subtitle" },
                    new SpacingBetweenLines() { After = "120" })
            });

            body.AppendChild(new Paragraph(new Run(new Text($"Author: {author}")))
            {
                ParagraphProperties = new ParagraphProperties(
                    new ParagraphStyleId() { Val = "Subtitle" },
                    new SpacingBetweenLines() { After = "120" })
            });

            body.AppendChild(new Paragraph(new Run(new Text($"Date: {DateTime.UtcNow:yyyy-MM-dd HH:mm} UTC")))
            {
                ParagraphProperties = new ParagraphProperties(
                    new ParagraphStyleId() { Val = "Subtitle" },
                    new SpacingBetweenLines() { After = "240" })
            });

            // Page break
            body.AppendChild(new Paragraph(new Run(new Break() { Type = BreakValues.Page })));
        }

        /// <summary>
        /// Adds Table of Contents field
        /// </summary>
        private void AddTableOfContents(Body body)
        {
            // TOC Heading
            body.AppendChild(new Paragraph(new Run(new Text("Table of Contents")))
            {
                ParagraphProperties = new ParagraphProperties(
                    new ParagraphStyleId() { Val = "TOCHeading" },
                    new SpacingBetweenLines() { After = "240" })
            });

            // TOC Field
            var tocParagraph = new Paragraph();
            var tocRun = new Run();
            
            tocRun.AppendChild(new FieldChar() { FieldCharType = FieldCharValues.Begin });
            tocRun.AppendChild(new FieldCode(" TOC \\o \"1-3\" \\h \\z \\u ") { Space = SpaceProcessingModeValues.Preserve });
            tocRun.AppendChild(new FieldChar() { FieldCharType = FieldCharValues.Separate });
            tocRun.AppendChild(new FieldChar() { FieldCharType = FieldCharValues.End });
            
            tocParagraph.AppendChild(tocRun);
            tocParagraph.ParagraphProperties = new ParagraphProperties(
                new SpacingBetweenLines() { After = "240" });
            
            body.AppendChild(tocParagraph);
            body.AppendChild(new Paragraph(new Run(new Break() { Type = BreakValues.Page })));
        }

        /// <summary>
        /// Adds revision history table
        /// </summary>
        private void AddRevisionHistory(Body body, string author, string summary)
        {
            body.AppendChild(new Paragraph(new Run(new Break() { Type = BreakValues.Page })));
            
            body.AppendChild(new Paragraph(new Run(new Text("7. Revision History")))
            {
                ParagraphProperties = new ParagraphProperties(
                    new ParagraphStyleId() { Val = "Heading1" },
                    new SpacingBetweenLines() { Before = "480", After = "240" })
            });

            // Create revision history table
            var table = new Table(
                new TableProperties(
                    new TableBorders(
                        new TopBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 4 },
                        new BottomBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 4 },
                        new LeftBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 4 },
                        new RightBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 4 },
                        new InsideHorizontalBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 4 },
                        new InsideVerticalBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 4 })),
                
                // Header row
                new TableRow(
                    new TableCell(new Paragraph(new Run(new Text("Date")))
                    {
                        ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "TableHeading" })
                    }),
                    new TableCell(new Paragraph(new Run(new Text("Author")))
                    {
                        ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "TableHeading" })
                    }),
                    new TableCell(new Paragraph(new Run(new Text("Change Summary")))
                    {
                        ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "TableHeading" })
                    })),
                
                // Initial revision
                new TableRow(
                    new TableCell(new Paragraph(new Run(new Text(DateTime.UtcNow.ToString("yyyy-MM-dd"))))
                    {
                        ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "TableContent" })
                    }),
                    new TableCell(new Paragraph(new Run(new Text(author)))
                    {
                        ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "TableContent" })
                    }),
                    new TableCell(new Paragraph(new Run(new Text(summary)))
                    {
                        ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "TableContent" })
                    }))
            );

            body.AppendChild(table);
        }

        // Image handling helpers (reused from TemplateBuilder)
        private static ImagePartType DetectImageFormat(byte[] imgBytes)
        {
            if (imgBytes.Length < 8) return ImagePartType.Png;

            if (imgBytes[0] == 0x89 && imgBytes[1] == 0x50 && imgBytes[2] == 0x4E && imgBytes[3] == 0x47)
                return ImagePartType.Png;
            if (imgBytes[0] == 0xFF && imgBytes[1] == 0xD8)
                return ImagePartType.Jpeg;
            if (imgBytes[0] == 0x47 && imgBytes[1] == 0x49 && imgBytes[2] == 0x46)
                return ImagePartType.Gif;
            if (imgBytes[0] == 0x42 && imgBytes[1] == 0x4D)
                return ImagePartType.Bmp;

            return ImagePartType.Png;
        }

        private static (long widthEmu, long heightEmu) CalculateImageDimensions(byte[] imgBytes)
        {
            try
            {
                int width = 0, height = 0;
                
                if (imgBytes.Length >= 24 && 
                    imgBytes[0] == 0x89 && imgBytes[1] == 0x50 && imgBytes[2] == 0x4E && imgBytes[3] == 0x47)
                {
                    width = (imgBytes[16] << 24) | (imgBytes[17] << 16) | (imgBytes[18] << 8) | imgBytes[19];
                    height = (imgBytes[20] << 24) | (imgBytes[21] << 16) | (imgBytes[22] << 8) | imgBytes[23];
                }
                else if (imgBytes.Length >= 20 && imgBytes[0] == 0xFF && imgBytes[1] == 0xD8)
                {
                    for (int i = 2; i < Math.Min(imgBytes.Length - 7, 1000); i++)
                    {
                        if (imgBytes[i] == 0xFF && (imgBytes[i + 1] >= 0xC0 && imgBytes[i + 1] <= 0xC3))
                        {
                            height = (imgBytes[i + 5] << 8) | imgBytes[i + 6];
                            width = (imgBytes[i + 7] << 8) | imgBytes[i + 8];
                            break;
                        }
                    }
                }
                else if (imgBytes.Length >= 10 && 
                         imgBytes[0] == 0x47 && imgBytes[1] == 0x49 && imgBytes[2] == 0x46)
                {
                    width = imgBytes[6] | (imgBytes[7] << 8);
                    height = imgBytes[8] | (imgBytes[9] << 8);
                }
                
                if (width > 0 && height > 0)
                {
                    const long maxWidthEmu = 576000L;
                    const long emuPerPixel = 9525L;
                    
                    var widthEmu = (long)width * emuPerPixel;
                    var heightEmu = (long)height * emuPerPixel;
                    
                    if (widthEmu > maxWidthEmu)
                    {
                        var scale = (double)maxWidthEmu / widthEmu;
                        widthEmu = maxWidthEmu;
                        heightEmu = (long)(heightEmu * scale);
                    }
                    
                    return (widthEmu, heightEmu);
                }
            }
            catch { }
            
            return (576000L, 432000L);
        }

        private static DrawingWordprocessing.Inline CreateImageInline(string imageRelId, long widthEmu, long heightEmu, int idx, string altText)
        {
            var picture = new Drawing.Pictures.Picture(
                new Drawing.Pictures.NonVisualPictureProperties(
                    new Drawing.Pictures.NonVisualDrawingProperties() 
                    { 
                        Id = (UInt32Value)(idx + 1U), 
                        Name = $"Image {idx}",
                        Description = altText
                    },
                    new Drawing.Pictures.NonVisualPictureDrawingProperties()),
                new Drawing.Pictures.BlipFill(
                    new Drawing.Blip() { Embed = imageRelId },
                    new Drawing.Stretch(new Drawing.FillRectangle())),
                new Drawing.Pictures.ShapeProperties(
                    new Drawing.Transform2D(
                        new Drawing.Offset() { X = 0L, Y = 0L },
                        new Drawing.Extents() { Cx = widthEmu, Cy = heightEmu }),
                    new Drawing.PresetGeometry() { Preset = Drawing.ShapeTypeValues.Rectangle }));

            var graphicData = new Drawing.GraphicData(picture)
            {
                Uri = "http://schemas.openxmlformats.org/drawingml/2006/picture"
            };

            var graphic = new Drawing.Graphic(graphicData);

            var inline = new DrawingWordprocessing.Inline(
                new DrawingWordprocessing.Extent() { Cx = widthEmu, Cy = heightEmu },
                new DrawingWordprocessing.EffectExtent() 
                { 
                    LeftEdge = 0L, 
                    TopEdge = 0L, 
                    RightEdge = 0L, 
                    BottomEdge = 0L 
                },
                new DrawingWordprocessing.DocProperties() 
                { 
                    Id = (UInt32Value)(idx + 1U), 
                    Name = $"Image {idx}",
                    Description = altText
                },
                new DrawingWordprocessing.NonVisualGraphicFrameDrawingProperties(
                    new Drawing.GraphicFrameLocks() { NoChangeAspect = true }),
                graphic)
            {
                DistanceFromTop = 0,
                DistanceFromBottom = 0,
                DistanceFromLeft = 0,
                DistanceFromRight = 0
            };
            
            return inline;
        }

        private static OpenXmlUnknownElement CreateDrawingWrapper(DrawingWordprocessing.Inline inline)
        {
            var drawing = new OpenXmlUnknownElement(
                "w:drawing",
                "http://schemas.openxmlformats.org/wordprocessingml/2006/main");
            drawing.AppendChild(inline);
            return drawing;
        }
    }

    /// <summary>
    /// Mapping configuration model
    /// </summary>
    public class MappingConfig
    {
        public List<SectionRule> Sections { get; set; } = new();
        public List<string> FunctionalKeywords { get; set; } = new();
        public List<string> TechnicalKeywords { get; set; } = new();
        public List<string> SupportKeywords { get; set; } = new();
    }

    /// <summary>
    /// Section mapping rule
    /// </summary>
    public class SectionRule
    {
        public string Name { get; set; } = string.Empty;
        public List<string> Keywords { get; set; } = new();
        public bool Mandatory { get; set; }
    }

    /// <summary>
    /// Enrichment result
    /// </summary>
    public class EnrichmentResult
    {
        public bool Success { get; set; }
        public string DocumentType { get; set; } = string.Empty;
        public string EnrichedPath { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public string ErrorMessage { get; set; } = string.Empty;
    }
}

